export const data1 = [
  {
    id: 1,
    title: "Let's\nhave the\nbest\nvacation\nwith us ",
    info: ' (1)Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
    //image:'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/13/69/65/e9/poolside.jpg?w=900&h=-1&s=1',
    image: require('../../asset/banner/hotel.jpeg'),
  },
];

export const data2 = [
  {
    id: 2,
    title: 'Travel\nmade easy\nin your\nhands',
    info: ' (2)Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
    //image:'https://media.istockphoto.com/photos/luxury-resort-picture-id104731717?k=20&m=104731717&s=612x612&w=0&h=40INtJRzhmU1O4Rj24zdY8vj4aGsWpPaEfojaVQ8xBo=',
    image: require('../../asset/banner/hotel1.jpeg'),
  },
];

export const data3 = [
  {
    id: 3,
    title: "Let's\ndiscover\nthe world\nwith us",
    info: ' (3)Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
    //image:'https://www.berjayahotel.com/sites/default/files/colombo_30.jpg',
    image: require('../../asset/banner/hotel2.jpeg'),
  },
];
