import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/FontAwesome';
import CheckBox from 'react-native-check-box';

export default AccountPage = ({navigation}) => {
  return (
    <ScrollView style={{flex: 1}}>
      <View style={{flex: 1}}>
        <View
          style={{
            flex: 2,
            borderRadius: 20,

            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text style={{fontSize: 40, color: 'black', fontWeight: 'bold'}}>
            Create Your Account
          </Text>
        </View>
        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
          }}>
          <Icon name="envelope" size={20} color="gray" />
          <TextInput placeholder="Email" />
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
          }}>
          <Icon name="lock" size={20} color="gray" />
          <TextInput placeholder="PASSWORD" secureTextEntry />
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
            justifyContent: 'center',
          }}>
          <CheckBox />
          <Text>Remember me</Text>
        </View>
        <View
          style={{
            flex: 1,
            borderRadius: 40,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'green',
            padding: 20,
          }}>
          <TouchableOpacity onPress={() => navigation.navigate('fillinfo')}>
            <Text style={{color: 'white', fontSize: 20}}>SignUp</Text>
          </TouchableOpacity>
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <View style={{flex: 1, height: 2, backgroundColor: 'black'}}></View>
          <Text style={{flex: 1, textAlign: 'center'}}>Or Continue With</Text>
          <View style={{flex: 1, height: 2, backgroundColor: 'black'}}></View>
        </View>

        <View style={{flex: 1, flexDirection: 'row'}}>
          <View
            style={{
              flex: 1,
              borderRadius: 20,
              borderWidth: 1,
              marginTop: 10,
              margin: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 20,
            }}>
            <TouchableOpacity
              onPress={() => alert('API Not Connect....')}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={require('../../asset/logo/google.png')}
                style={{width: 30, height: 30}}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              flex: 1,
              borderRadius: 20,
              borderWidth: 1,
              marginTop: 10,
              margin: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 20,
            }}>
            <TouchableOpacity
              onPress={() => alert('API Not Connect....')}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={require('../../asset/logo/fb.png')}
                style={{width: 30, height: 30}}
              />
            </TouchableOpacity>
          </View>
          <View
            style={{
              flex: 1,
              borderRadius: 20,
              borderWidth: 1,
              marginTop: 10,
              margin: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 20,
            }}>
            <TouchableOpacity
              onPress={() => alert('API Not Connect....')}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={require('../../asset/logo/apple.png')}
                style={{width: 30, height: 30}}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text> Already have a account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('login')}>
            <Text style={{color: 'green', fontWeight: 'bold'}}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};
