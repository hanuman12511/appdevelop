import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';

export default Otp = ({navigation}) => {
  return (
    <ScrollView style={{flex: 1, position: 'relative'}}>
      <View
        style={{
          flex: 1,
          borderRadius: 20,
          marginTop: 250,
          margin: 20,
          alignItems: 'center',
        }}>
        <Text>Code has been send to +91 9829****99</Text>
        <View style={{flex: 1, flexDirection: 'row', marginTop: 30}}>
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: 'gray',
              padding: 20,
              marginLeft: 10,
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: 'gray',
              padding: 20,
              marginLeft: 10,
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: 'gray',
              padding: 20,
              marginLeft: 10,
            }}
          />
          <TextInput
            style={{
              width: 70,
              height: 70,
              borderRadius: 10,
              backgroundColor: 'gray',
              padding: 20,
              marginLeft: 10,
            }}
          />
        </View>
      </View>

      <View
        style={{
          flex: 1,
          borderRadius: 20,
          marginTop: 50,
          margin: 20,
          alignItems: 'center',
          position: 'relative',
        }}>
        <Text>Resend code in 54 s</Text>
      </View>
      <View
        style={{
          flex: 1,
          borderRadius: 40,

          margin: 20,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'green',
          padding: 20,
        }}>
        <TouchableOpacity onPress={() => navigation.navigate('newpassword')}>
          <Text style={{color: 'white', fontSize: 20}}>Verify</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};
