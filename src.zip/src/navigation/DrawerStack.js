import React from 'react';
import {NavigationContainer, DrawerActions} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import MainPage from '../screens/MainPage';
import Home from '../screens/Home';

import NavBottomTab from '../components/NavBottomTab';
import CustDrawer from '../components/CustDrawer';
import TopNav from '../components/TopNav';
import MainHomePage from '../screens/HomeScreen/MainHomePage';
const Drawer = createDrawerNavigator();

export default DrawerStack = () => {
  return (
    <Drawer.Navigator
      drawerContent={props => <CustDrawer {...props} />}
      screenOptions={{drawerStyle: {width: '100%'}, headerShown: false}}>
      <Drawer.Screen name="MainPage" component={NavBottomTab} />
      <Drawer.Screen name="Nav" component={NavBottomTab} />
      <Drawer.Screen name="NavTop" component={TopNav} />
    </Drawer.Navigator>
  );
};
