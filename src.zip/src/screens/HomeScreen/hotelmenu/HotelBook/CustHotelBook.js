import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Hotelcatedata from '../../../../utils/hotelinfo/Hotelcatedata';

const Ongoing = () => {
  return (
    <View
      style={{
        marginLeft: 20,
        marginRight: 20,
        borderRadius: 20,
        flexDirection: 'row',
      }}>
      <View
        style={{
          borderWidth: 1,
          flex: 1,
          padding: 10,
          borderTopLeftRadius: 15,
          borderBottomLeftRadius: 15,
          borderColor: 'green',
        }}>
        <Text style={{color: 'green', textAlign: 'center'}}>CancleBooking</Text>
      </View>
      <View
        style={{
          backgroundColor: 'green',
          flex: 1,
          padding: 10,
          borderTopRightRadius: 15,
          borderBottomRightRadius: 15,
        }}>
        <Text style={{color: 'white', textAlign: 'center'}}>View Ticket</Text>
      </View>
    </View>
  );
};

const Cancle = () => {
  return <Text>Cancled This Hotel Booking</Text>;
};

const Complate = () => {
  return <Text>Complate This Hotel Booking</Text>;
};

export default CustHotelBook = props => {
  const [menucolor, setMenuColor] = useState(1);
  return (
    <>
      <FlatList
        style={{margin: 0}}
        data={Hotelcatedata}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('girlswear')}
            underlayColor="white">
            <View
              style={{
                flex: 1,
                margin: 10,
                marginLeft: 10,
                marginRight: 10,
                backgroundColor: 'white',
                flexDirection: 'row',
                padding: 5,
                paddingTop: 20,
                paddingBottom: 20,
                borderRadius: 20,
                marginTop: 10,
              }}>
              <View style={{flex: 1}}>
                <Image
                  source={item.image}
                  style={{
                    height: '100%',
                    width: '100%',
                    borderRadius: 10,
                    marginLeft: 5,
                  }}
                />
              </View>
              <View style={{flex: 2, alignItems: 'flex-start', marginLeft: 20}}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: 'black',
                  }}>
                  {item.name}
                </Text>
                <Text style={{fontSize: 12, marginTop: 10, marginBottom: 10}}>
                  {item.place}
                </Text>

                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: props.bgcolor,
                    padding: 10,
                    borderRadius: 10,
                  }}>
                  <Text style={{color: props.color}}>{props.paystatus}</Text>
                </View>
              </View>
            </View>

            <View style={{flex: 1}}>
              {props.paystatus == 'paid' ? (
                <Ongoing />
              ) : props.paystatus == 'complated' ? (
                <Complate />
              ) : (
                <Cancle />
              )}
            </View>
          </TouchableOpacity>
        )}
      />
    </>
  );
};
