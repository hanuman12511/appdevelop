import React from 'react';
import {View, Text, ScrollView} from 'react-native';

import SearchBar from '../../../components/SearchBar';

import HotelMenu from './HotelMenu';
import RecentlyBooked from './RecentlyBooked';

export default SearchHotel = () => {
  return (
    <ScrollView style={{flex: 1, marginTop: 20}}>
      <View style={{flex: 1}}>
        <SearchBar />
      </View>

      <View style={{flex: 1}}>
        <HotelMenu />
      </View>

      <View style={{flex: 1}}>
        <RecentlyBooked />
      </View>
    </ScrollView>
  );
};
