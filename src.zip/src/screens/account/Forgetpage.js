import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/FontAwesome';
import CheckBox from 'react-native-check-box';

export default Forgetpage = ({navigation}) => {
  return (
    <ScrollView style={{flex: 1}}>
      <View style={{flex: 1}}>
        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
            justifyContent: 'center',
          }}>
          <Image
            source={require('../../asset/logo/lock.webp')}
            style={{
              width: 150,
              height: 150,
              borderRadius: 100,
              borderColor: 'black',
              borderWidth: 1,
            }}
          />
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
          }}>
          <Text>
            Select which contact details should we use to reset you password
          </Text>
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
            padding: 30,
          }}>
          <Icon name="comment" size={20} color="gray" />

          <Text style={{marginLeft: 20}}> via SMS {'\n'} +91-9829****99</Text>
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
            padding: 30,
          }}>
          <Icon name="envelope" size={20} color="gray" />

          <Text style={{marginLeft: 20}}>
            via Email {'\n'} han***s@gmail.com
          </Text>
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 40,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'green',
            padding: 20,
          }}>
          <TouchableOpacity onPress={() => navigation.navigate('otp')}>
            <Text style={{color: 'white', fontSize: 20}}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};
