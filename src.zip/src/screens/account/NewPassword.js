import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import Icon from 'react-native-vector-icons/FontAwesome';
import CheckBox from 'react-native-check-box';

export default Forgetpage = ({navigation}) => {
  return (
    <ScrollView style={{flex: 1}}>
      <View style={{flex: 1}}>
        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
            justifyContent: 'center',
          }}>
          <Image
            source={require('../../asset/logo/lock.webp')}
            style={{
              width: 150,
              height: 150,
              borderRadius: 100,
              borderColor: 'black',
              borderWidth: 1,
            }}
          />
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
          }}>
          <Text>Create Your New Password</Text>
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
          }}>
          <Icon name="lock" size={20} color="gray" />
          <TextInput placeholder="PASSWORD" secureTextEntry />
        </View>

        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            borderWidth: 1,
            paddingLeft: 20,
          }}>
          <Icon name="lock" size={20} color="gray" />
          <TextInput placeholder="PASSWORD" secureTextEntry />
        </View>
        <View
          style={{
            flex: 1,
            borderRadius: 20,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flexDirection: 'row',
            paddingLeft: 20,
            justifyContent: 'center',
          }}>
          <CheckBox />
          <Text>Remember me</Text>
        </View>
        <View
          style={{
            flex: 1,
            borderRadius: 40,
            marginTop: 10,
            margin: 20,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'green',
            padding: 20,
          }}>
          <TouchableOpacity onPress={() => navigation.navigate('mainhomepage')}>
            <Text style={{color: 'white', fontSize: 20}}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};
