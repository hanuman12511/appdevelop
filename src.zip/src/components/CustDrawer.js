import React from 'react';
import {View, Text} from 'react-native';
import {
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';

import Icon from 'react-native-vector-icons/FontAwesome';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {DrawerActions} from '@react-navigation/native';

const CustDrawerPage = props => {
  return (
    <View
      style={{
        flex: 1,
        flexDirection: 'row',
        backgroundColor: 'pink',
        margin: 0,
        padding: 20,
        alignItems: 'center',
        justifyContent: 'flex-end',
      }}>
      <Text style={{fontSize: 25, flex: 1}}>Hanuman Saini</Text>
      <TouchableOpacity onPress={() => props.navigation.closeDrawer()}>
        <Icon name="close" color="red" size={25} />
      </TouchableOpacity>
    </View>
  );
};

export default CustDrawer = props => {
  return (
    <View style={{flexGrow: 1}}>
      <DrawerContentScrollView
        {...props}
        contentContainerStyle={{backgroundColor: 'red'}}>
        <CustDrawerPage {...props} />

        <DrawerItemList {...props} />
        <DrawerItem label="Home" />
      </DrawerContentScrollView>
    </View>
  );
};
