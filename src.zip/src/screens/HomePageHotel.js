import React, {useState} from 'react';
import {
  FlatList,
  SafeAreaView,
  View,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import hotel from '../asset/banner/hotel1.jpeg';
import Hotel from './Hotel';

import {data1, data2, data3} from '../utils/hotelinfo/Data';

export default HomePageHotel = ({navigation}) => {
  const [btncolor, setBtnColor] = useState('next');
  const [datao, setData] = useState(0);
  const data = datao == 1 ? data1 : datao == 2 ? data2 : data3;

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
      <FlatList
        data={data}
        renderItem={({item}) => (
          <Hotel info={item.info} title={item.title} image={item.image} />
        )}
        keyExtractor={item => item.id}
      />

      <View
        style={{
          position: 'absolute',
          bottom: 0,
          flex: 1,
          flexDirection: 'row',
        }}>
        <Text
          onPress={() => {
            if (datao < 2) {
              setData(datao + 1);
              setBtnColor('next');
            } else {
              setData(0);
              setBtnColor('next');
            }
          }}
          style={{
            borderRadius: 10,
            color: 'white',
            fontSize: 20,
            textAlign: 'center',
            flex: 1,
            backgroundColor: btncolor == 'next' ? 'green' : 'gray',
            padding: 15,
            margin: 10,
          }}>
          Next
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate('AccountPage')}>
          <Text
            /*   onPress={() => setBtnColor('skip')} */
            style={{
              borderRadius: 10,
              color: 'white',
              fontSize: 20,
              textAlign: 'center',
              flex: 1,
              backgroundColor: btncolor == 'skip' ? 'green' : 'gray',
              padding: 15,
              margin: 10,
            }}>
            Skip
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};
