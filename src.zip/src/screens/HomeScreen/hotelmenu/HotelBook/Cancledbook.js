import React from 'react';
import {View, Text, ScrollView} from 'react-native';
import CustHotelBook from './CustHotelBook';
export default Cancledbook = () => {
  return (
    <ScrollView style={{flex: 1, marginTop: 20}}>
      <View style={{flex: 1}}>
        <CustHotelBook
          paystatus="Cancled & Refunded "
          bgcolor="red"
          color="white"
        />
      </View>
    </ScrollView>
  );
};
