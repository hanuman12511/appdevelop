import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Hotelcatedata from '../../../utils/hotelinfo/Hotelcatedata';

export default HotelCate = ({navigation}) => {
  const [menucolor, setMenuColor] = useState(1);
  return (
    <>
      <FlatList
        style={{margin: 0}}
        data={Hotelcatedata}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('girlswear')}
            underlayColor="white">
            <View
              style={{
                flex: 1,
                margin: 10,
                marginLeft: 10,
                marginRight: 10,
                backgroundColor: 'white',
                flexDirection: 'row',
                padding: 5,
                paddingTop: 20,
                paddingBottom: 20,
                borderRadius: 20,
                marginTop: 10,
              }}>
              <View style={{flex: 1}}>
                <Image
                  source={item.image}
                  style={{
                    height: '100%',
                    width: '100%',
                    borderRadius: 10,
                    marginLeft: 5,
                  }}
                />
              </View>
              <View style={{flex: 1.5, alignItems: 'center'}}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: 'black',
                  }}>
                  {item.name}
                </Text>
                <Text style={{fontSize: 12, marginTop: 10, marginBottom: 10}}>
                  {item.place}
                </Text>

                <View
                  style={{flex: 1, flexDirection: 'row', alignItems: 'center'}}>
                  <Icon name="star" size={15} color="gold" />
                  <Text style={{marginLeft: 5, color: 'green'}}>
                    {item.rate}
                  </Text>
                  <Text style={{marginLeft: 5, fontSize: 10}}>
                    ({item.review} reviews)
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: 20,
                    fontWeight: 'bold',
                    color: 'green',
                  }}>
                  {item.price}
                </Text>
                <Text style={{fontSize: 10, marginTop: 0}}>/par nigit</Text>
                <Icon
                  name="bookmark"
                  size={15}
                  color="green"
                  style={{marginTop: 10}}
                />
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </>
  );
};
