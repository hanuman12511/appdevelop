import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Hotelcatedata from '../../../utils/hotelinfo/Hotelcatedata';

export default HotelCate = ({navigation}) => {
  const [menucolor, setMenuColor] = useState(1);
  return (
    <FlatList
      style={{margin: 0}}
      data={Hotelcatedata}
      keyExtractor={item => item.id}
      horizontal
      renderItem={({item}) => (
        <View
          style={{
            flex: 1,
            margin: 2,
            marginLeft: 2,
            backgroundColor: '#00BFA5',
            justifyContent: 'center',
            alignItems: 'center',
            padding: 5,
            borderRadius: 40,
            marginTop: 30,
          }}>
          <TouchableOpacity
            onPress={() => navigation.navigate('girlswear')}
            underlayColor="white">
            <View
              style={{
                flex: 1,
                padding: 2,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Image
                source={item.image}
                style={{
                  height: 200,
                  width: 200,
                  borderRadius: 40,
                }}
              />
              <View
                style={{
                  width: 200,
                  height: 200,
                  position: 'absolute',
                  backgroundColor: 'black',
                  borderRadius: 40,
                  opacity: 0.6,
                }}></View>
              <View
                style={{
                  position: 'absolute',
                  right: 15,
                  top: 15,
                  flexDirection: 'row',
                  backgroundColor: 'green',
                  paddingLeft: 10,
                  paddingRight: 10,
                  alignItems: 'center',
                  padding: 5,
                  borderRadius: 20,
                }}>
                <Icon name="star" size={15} color="white" />
                <Text style={{color: 'white', marginLeft: 10}}>
                  {item.rate}
                </Text>
              </View>

              <View
                style={{
                  position: 'absolute',
                  right: 15,
                  bottom: 15,
                  flexDirection: 'row',
                  paddingLeft: 10,
                  paddingRight: 10,
                  alignItems: 'center',
                  padding: 5,
                }}>
                <Icon name="bookmark" size={15} color="white" />
              </View>

              <View style={{position: 'absolute', left: 15, bottom: 30}}>
                <Text
                  style={{color: 'white', fontSize: 20, fontWeight: 'bold'}}>
                  {item.name}
                </Text>
                <Text style={{color: 'white', fontSize: 15}}>{item.name}</Text>
                <View style={{flex: 1, flexDirection: 'row'}}>
                  <Text
                    style={{
                      color: 'white',
                      fontSize: 20,
                      fontWeight: 'bold',
                    }}>
                    {item.price}
                  </Text>
                  <Text style={{color: 'white', fontSize: 15, marginTop: 5}}>
                    /par nigit
                  </Text>
                </View>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      )}
    />
  );
};
