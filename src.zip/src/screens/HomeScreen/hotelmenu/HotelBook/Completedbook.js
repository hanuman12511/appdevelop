import React from 'react';
import {View, Text, ScrollView} from 'react-native';
import CustHotelBook from './CustHotelBook';
export default Completedbook = () => {
  return (
    <ScrollView style={{flex: 1, marginTop: 20}}>
      <View style={{flex: 1}}>
        <CustHotelBook paystatus="complated" bgcolor="green" color="white" />
      </View>
    </ScrollView>
  );
};
