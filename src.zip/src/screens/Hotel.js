import React, {useState} from 'react';
import {
  SafeAreaView,
  View,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import hotel from '../asset/banner/hotel1.jpeg';

const data1 = [
  {
    id: 1,
    title: "Let's\nhave the\nbest\nvacation\nwith us ",
    info: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
  },
];

const data2 = [
  {
    id: 2,
    title: 'Travel\nmade easy\nin your\nhands',
    info: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
  },
];

const data3 = [
  {
    id: 3,
    title: "Let's\ndiscover\nthe world\nwith us",
    info: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur soluta eum eligendi autem iure, aliquid ducimus optio assumenda natus maxime.',
  },
];

export default Hotel = props => {
  const [btncolor, setBtnColor] = useState('next');
  const [datao, setData] = useState(0);
  const data = datao == 1 ? data1 : datao == 2 ? data2 : data3;
  const img = props.image;
  return (
    <View style={{width: '100%', height: 600}}>
      <ImageBackground
        source={props.image}
        style={{width: 450, height: 490, marginLeft: 30}}
      />

      <View
        style={{
          width: 200,
          height: 200,
          borderRadius: 0,
          rotation: 50,
          position: 'absolute',
          top: -100,
          backgroundColor: 'white',
          bottom: 0,
          left: -70,
          right: 0,
        }}></View>
      <View
        style={{
          width: 300,
          height: 900,
          borderRadius: 50,
          rotation: -40,
          position: 'absolute',
          top: 0,
          backgroundColor: 'white',
          bottom: 0,
          left: -70,
          right: 0,
        }}></View>
      <View
        style={{
          width: 500,
          height: 500,
          borderRadius: 50,
          rotation: -40,
          position: 'absolute',
          top: -80,
          bottom: 0,
          left: 100,
          right: 0,
          borderWidth: 20,
          borderColor: 'white',
          borderColor: '#F7F5F2',
        }}></View>
      <View style={{position: 'absolute', bottom: 0, top: 300}}>
        <View style={{height: '60%'}}>
          <Text style={{fontSize: 30, fontWeight: 'bold', marginLeft: 20}}>
            {props.title}
          </Text>
        </View>
        <View>
          <Text style={{fontSize: 16, padding: 20, color: 'black'}}>
            {props.info}
          </Text>
        </View>
      </View>
    </View>
  );
};
