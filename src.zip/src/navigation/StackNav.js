import React from 'react';

import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import HomePageHotel from '../screens/HomePageHotel';
import AccountPage from '../screens/account/AccountPage';
import Signup from '../screens/account/Signup';
import Profileupdate from '../screens/account/Profileupdate';
import Login from '../screens/account/Login';
import MainHomePage from '../screens/HomeScreen/MainHomePage';
import Forgetpage from '../screens/account/Forgetpage';
import Otp from '../screens/account/Otp';
import NewPassword from '../screens/account/NewPassword';
import DrawerStack from './DrawerStack';
const Stack = createNativeStackNavigator();

export default StackNav = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="HomePageHotel"
        screenOptions={{headerShown: false}}>
        <Stack.Screen name="AccountPage" component={AccountPage} />
        <Stack.Screen name="HomePageHotel" component={HomePageHotel} />
        <Stack.Screen name="signup" component={Signup} />
        <Stack.Screen name="fillinfo" component={Profileupdate} />
        <Stack.Screen name="login" component={Login} />
        <Stack.Screen name="mainhomepage" component={DrawerStack} />
        <Stack.Screen name="forgetpage" component={Forgetpage} />
        <Stack.Screen name="otp" component={Otp} />
        <Stack.Screen name="newpassword" component={NewPassword} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
