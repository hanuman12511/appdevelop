import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';

import Hotelmenudata from '../../../utils/hotelinfo/Hotelmenudata';

export default HotelMenu = ({navigation}) => {
  const [menucolor, setMenuColor] = useState(1);
  return (
    <FlatList
      data={Hotelmenudata}
      renderItem={({item}) => (
        <View style={{flex: 1, marginTop: 10}}>
          <TouchableOpacity onPress={() => navigation.navigate(item.menu)}>
            <Text
              onPress={() => setMenuColor(item.id)}
              style={{
                padding: 10,
                borderRadius: 20,
                borderWidth: 1,
                marginLeft: 10,
                color: 'green',
                borderColor: 'green',
                backgroundColor: menucolor === item.id ? 'green' : 'white',
                color: menucolor === item.id ? 'white' : 'green',
              }}>
              {item.menu}
            </Text>
          </TouchableOpacity>
        </View>
      )}
      keyExtractor={item => item.id}
      horizontal
    />
  );
};
