import React from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

export default AccountPage = ({navigation}) => {
  return (
    <View style={{flex: 1}}>
      <View
        style={{
          flex: 2,
          borderRadius: 20,

          marginTop: 10,
          margin: 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text style={{fontSize: 40, color: 'black'}}>Let's You in </Text>
      </View>

      <View
        style={{
          flex: 1,
          borderRadius: 20,
          borderWidth: 1,
          margin: 20,
        }}>
        <TouchableOpacity
          onPress={() => alert('API Not Connect....')}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 10,
            margin: 20,
          }}>
          <Image
            source={require('../../asset/logo/google.png')}
            style={{width: 40, height: 40, marginLeft: '10%'}}
          />
          <Text>Continue with Google</Text>
        </TouchableOpacity>
      </View>

      <View
        style={{
          flex: 1,
          borderRadius: 20,
          borderWidth: 1,
          marginTop: 10,
          margin: 20,
        }}>
        <TouchableOpacity
          onPress={() => alert('API Not Connect....')}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 10,
            margin: 20,
          }}>
          <Image
            source={require('../../asset/logo/fb.png')}
            style={{width: 40, height: 40, marginLeft: '10%'}}
          />
          <Text>Continue with Facebook </Text>
        </TouchableOpacity>
      </View>

      <View
        style={{
          flex: 1,
          borderRadius: 20,
          borderWidth: 1,
          marginTop: 10,
          margin: 20,
        }}>
        <TouchableOpacity
          onPress={() => alert('API Not Connect....')}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 10,
            margin: 20,
          }}>
          <Image
            source={require('../../asset/logo/apple.png')}
            style={{width: 40, height: 40, marginLeft: '10%'}}
          />
          <Text>Continue with Apple</Text>
        </TouchableOpacity>
      </View>

      <View
        style={{
          flex: 1,
          borderRadius: 20,
          marginTop: 10,
          margin: 20,
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <View style={{flex: 2, height: 2, backgroundColor: 'black'}}></View>
        <Text style={{flex: 1, textAlign: 'center'}}>Or</Text>
        <View style={{flex: 2, height: 2, backgroundColor: 'black'}}></View>
      </View>
      <View
        style={{
          flex: 1,
          borderRadius: 40,
          marginTop: 10,
          margin: 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'green',
        }}>
        <TouchableOpacity onPress={() => navigation.navigate('login')}>
          <Text style={{color: 'white', fontSize: 20}}>
            Sign in with password
          </Text>
        </TouchableOpacity>
      </View>
      <View
        style={{
          flex: 1,
          borderRadius: 20,
          marginTop: 10,
          margin: 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Text> Don't have a account? </Text>
        <TouchableOpacity onPress={() => navigation.navigate('signup')}>
          <Text style={{color: 'green', fontWeight: 'bold'}}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};
