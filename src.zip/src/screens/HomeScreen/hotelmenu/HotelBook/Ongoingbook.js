import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Hotelcatedata from '../../../../utils/hotelinfo/Hotelcatedata';
import CustHotelBook from './CustHotelBook';

export default Ongoingbook = ({navigation}) => {
  const [menucolor, setMenuColor] = useState(1);
  return <CustHotelBook paystatus="paid" bgcolor="green" color="white" />;
};
