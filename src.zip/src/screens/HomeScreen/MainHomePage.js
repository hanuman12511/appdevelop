import React from 'react';
import {
  View,
  SafeAreaView,
  Text,
  Image,
  TextInput,
  FlatList,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

import hlogo from '../../asset/logo/hlogo.webp';
import Icon from 'react-native-vector-icons/FontAwesome';
import HotelMenu from './hotelmenu/HotelMenu';
import HotelCate from './hotelmenu/HotelCate';
import RecentlyBooked from './hotelmenu/RecentlyBooked';
import SearchBar from '../../components/SearchBar';
export default MainHomePage = ({navigation}) => {
  console.log(Hotelmenudata);
  return (
    <ScrollView style={{flex: 1}}>
      <View
        style={{
          flex: 1,
          backgroundColor: 'green',
          marginTop: 0,
          padding: 20,
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        <View style={{flex: 1}}>
          <TouchableOpacity onPress={() => navigation.openDrawer()}>
            <Image source={hlogo} style={{width: 30, height: 30}} />
          </TouchableOpacity>
        </View>
        <View style={{flex: 2}}>
          <Text style={{color: 'white', fontSize: 20, marginLeft: 20}}>
            Helia
          </Text>
        </View>
        <View style={{flex: 1, alignItems: 'flex-end', flexDirection: 'row'}}>
          <Icon name="bell" color="white" size={20} />

          <Icon
            name="bookmark-o"
            color="white"
            size={20}
            style={{textAlign: 'right', marginLeft: 20}}
          />
        </View>
      </View>
      <View style={{flex: 1, padding: 20, flexDirection: 'row'}}>
        <Text style={{fontSize: 18, fontWeight: 'bold'}}>Hello,Hanuman</Text>
        <Icon
          name="hand-scissors-o"
          color="green"
          size={20}
          style={{marginLeft: 20}}
        />
      </View>

      <View style={{flex: 1}}>
        <SearchBar />
      </View>

      <View style={{flex: 1}}>
        <HotelMenu navigation={navigation} />
      </View>

      <View style={{flex: 1}}>
        <HotelCate navigation={navigation} />
      </View>
      <View style={{flex: 1}}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            backgroundColor: 'green',
            marginTop: 20,
          }}>
          <View style={{flex: 1}}>
            <Text style={{padding: 20, color: 'white', fontWeight: 'bold'}}>
              Recently Booked
            </Text>
          </View>

          <View style={{flex: 1}}>
            <Text
              style={{
                padding: 20,
                textAlign: 'right',
                color: 'white',
                fontWeight: 'bold',
              }}>
              See All
            </Text>
          </View>
        </View>

        <RecentlyBooked navigation={navigation} />
      </View>
    </ScrollView>
  );
};
