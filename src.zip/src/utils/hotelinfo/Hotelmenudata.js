export default Hotelmenudata = [
  {id: 1, menu: 'Recommended'},
  {id: 2, menu: 'Popular'},
  {id: 3, menu: 'Trending'},
  {id: 4, menu: 'NewOffer'},
  {id: 5, menu: 'NewOffer1'},
  {id: 6, menu: 'NewOffer2'},
];
